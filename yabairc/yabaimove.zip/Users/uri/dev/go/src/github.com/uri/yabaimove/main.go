package main

import (
	"fmt"
	"os"
	"strconv"
)

func main() {
	if len(os.Args) < 3 {
		os.Exit(1)
	}

	dir := os.Args[1]
	currentDisplay, err := strconv.Atoi(os.Args[2])

	if err != nil {
		os.Exit(1)
	}

	next := 0

	switch dir {
	case "west":
		switch currentDisplay {
		case 1:
			next = 3

		case 2:
			next = 1
		}

	case "east":
		switch currentDisplay {
		case 1:
			next = 2

		case 3:
			next = 1
		}

	}

	fmt.Println(next)
}
